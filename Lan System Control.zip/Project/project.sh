#!/bin/bash
SHARE_FILE ()
{
	clear
	service apache2 start
	echo "SHARE FILE"
    read -p "Enter the path to the file : " DIR
    #Checks if the file exists      
    if [[ -f "$DIR" ]]
    then
        cp -f "$DIR" /var/www/html
    	FILE="$(basename -- $DIR)" 
		service apache2 restart
		while read line; do	
            IP="$(grep -oE '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' <<< "$line")"  
			echo "cd C:/ && wget.exe -N $RASPI/$FILE && exit" | nc "$IP" 443
        done < "hosts.txt"
		rm -f /var/www/html/"$FILE"
	elif [[ -d "$DIR"]]
	then
	    zip -r "$DIR" "$DIR"
		cp -f "$DIR.zip" /var/www/html
    	FILE="$(basename -- $DIR)" 
		service apache2 restart
		while read line; do	
            IP="$(grep -oE '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' <<< "$line")"  
			echo "cd C:/ && wget.exe -N $RASPI/$FILE.zip && exit" | nc "$IP" 443
        done < "hosts.txt"
		rm -f /var/www/html/"$FILE.zip"
    else
		echo "The path to the file or directory does not exist."
	fi
}

SHUTDOWN_CLIENT () 
{
	clear
	echo "SHUTDOWN CLIENT"
        while read line; do
                IP="$(grep -oE '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' <<< "$line")"   
                echo "shutdown /s /t 5 && exit" | nc "$IP" 443 
        done < "hosts.txt"
}

CONNECT_CLIENT ()
{
	clear
	echo "CONNECT CLIENT"
	read -p "Enter the IP of the client : " CLIENT
	nc "$CLIENT" 443
}

clear 

echo "1. To shutdown the clients."
echo "2. To connect to a particular client."
echo "3. To share files to the clients."
echo "0. To exit."
read -p "Enter your choice[1-5] : " CHOICE

rm -f hosts.txt
GATEWAY=$(/sbin/ip route | awk '/default/ { print $3 }')
RASPI=$(ip -4 addr show usb0 | grep -oP '(?<=inet\s)\d+(\.\d+){3}')
nmap -n -sn "$GATEWAY"/24 --exclude "$RASPI","$GATEWAY" -oG - | awk '/Up$/{print $2}' > hosts.txt
case "$CHOICE" in
	1)
		SHUTDOWN_CLIENT
		;;
	2)
		CONNECT_CLIENT
		;;
	3)
		SHARE_FILE
		;;
	0)
		exit
		;;
	*)
		echo "Invalid Option"
		sleep 5

esac
echo "DONE"
sleep 5
./$(basename $0) && exit
